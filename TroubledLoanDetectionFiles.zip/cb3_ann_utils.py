# -*- coding: utf-8 -*-
"""
Created on Thu Jun 13 12:05:47 2019
Utility functions for training an artificial neural network
@author: CBarlow
"""
# Import packages
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import BatchNormalization
from keras import initializers
from keras import optimizers
from keras import regularizers
import fnmatch
import numpy as np
import os
import pandas as pd
from sklearn.model_selection import train_test_split

def load_and_normalize_loan_data(datasetFileNamePrefix, verbose=True):
    basepath = 'datasets/'
    firstFile = True
    if verbose:
        print("Joining the following datasets...")
    sortedFilenames = sorted(os.scandir(basepath), key=lambda e: e.name)
    for filename in sortedFilenames:
        if filename.is_file() and fnmatch.fnmatch(filename.name, datasetFileNamePrefix + '[0-9][0-9].csv'):
            if verbose:
                print('\t' + filename.name)
            if firstFile:
                original_data = pd.read_csv('./datasets/' + filename.name)
                original_data.set_index('LOAN_SERIAL', inplace=True)
                firstFile = False
            else:
                this_data = pd.read_csv('./datasets/' + filename.name)
                this_data.set_index('LOAN_SERIAL', inplace=True) 
                original_data = original_data.join(this_data)
    X=original_data.iloc[:,:-1]
    y = original_data[['BINARY_STATUS']].copy()
    
    # Split the data up in train and test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    # Further split training data into actual training and dev sets
    X_train, X_dev, y_train, y_dev = train_test_split(X_train, y_train, test_size=0.25)

    # Normalize the data
    train_mean = X_train.mean(axis=0)
    train_std = X_train.std(axis=0)
    train_std = np.where(train_std==0.0, 1.e-8, train_std) # avoid divide by zero error
    X_train -= train_mean
    X_train /= train_std
    # scale dev data and test data based on train data mean and standard deviation!
    X_dev -= train_mean
    X_dev /= train_std
    X_test -= train_mean
    X_test /= train_std
    
    n = X_train.shape[1]  # feature count
    return(X_train, y_train, X_dev, y_dev, X_test, y_test, n, train_mean, train_std)

def describe_datasets(X_train, y_train, X_dev, y_dev, X_test, y_test, n):
    totalDataSetSize = X_train.shape[0] + X_dev.shape[0] + X_test.shape[0]
    totalBadLoans = y_train.BINARY_STATUS.value_counts()[1] + y_dev.BINARY_STATUS.value_counts()[1] + y_test.BINARY_STATUS.value_counts()[1]
    totalGoodLoans = totalDataSetSize - totalBadLoans
    trainBadLoans = y_train.BINARY_STATUS.value_counts()[1]
    trainGoodLoans = X_train.shape[0] - trainBadLoans
    devBadLoans = y_dev.BINARY_STATUS.value_counts()[1]
    devGoodLoans = X_dev.shape[0] - devBadLoans
    testBadLoans = y_test.BINARY_STATUS.value_counts()[1]
    testGoodLoans = X_test.shape[0] - testBadLoans
    
    print("\n" + str(n)+" features")
    print("Total size of dataset: ", totalDataSetSize, "loans (", totalGoodLoans, " good; ", totalBadLoans, " bad)")
    print("Size of Original Training Set: ", X_train.shape[0], "loans (", trainGoodLoans, " good; ", trainBadLoans, " bad)")
    print("Size of Dev Set: ", X_dev.shape[0], "loans (", devGoodLoans, " good; ", devBadLoans, " bad)")
    print("Size of Test Set: ", X_test.shape[0], "loans (", testGoodLoans, " good; ", testBadLoans, " bad)")
    print()

# Define F1 score that does not give warning when Precision is ill-defined.
# Standard sklearn.metrics.f1_score(y_dev, y_pred) uses Precision*Recall/(Precision + Recall) definition, which is ill-defined
#               when precision is ill-defined due to no predictions of 1.
def my_f1_score(X, y, model):
    # Now make predictions on test data
    y_pred = model.predict(X)
    y_pred[y_pred>=0.5] = 1
    y_pred[y_pred<0.5] = 0
    y_numpy = y.to_numpy()
    
    (tp, tn, fp, fn) = cb3_calculateResults1(y_pred, y_numpy)
    (accuracy, precision, recall, f1, cm) = cb3_calculateResults2(tp, tn, fp, fn)

    return f1

# Define function to display a confusion matrix plot, given an sklearn confusion matrix
# in the form of a numpy array    
def cb3_plot_confusion_matrix(cm,
                          target_names,
                          title='Confusion matrix',
                          cmap=None,
                          normalize=True):
    """
    given a sklearn confusion matrix (cm), make a nice plot

    Arguments
    ---------
    cm:           confusion matrix from sklearn.metrics.confusion_matrix

    target_names: given classification classes such as [0, 1, 2]
                  the class names, for example: ['high', 'medium', 'low']

    title:        the text to display at the top of the matrix

    cmap:         the gradient of the values displayed from matplotlib.pyplot.cm
                  see http://matplotlib.org/examples/color/colormaps_reference.html
                  plt.get_cmap('jet') or plt.cm.Blues

    normalize:    If False, plot the raw numbers
                  If True, plot the proportions

    Usage
    -----
    plot_confusion_matrix(cm           = cm,                  # confusion matrix created by
                                                              # sklearn.metrics.confusion_matrix
                          normalize    = True,                # show proportions
                          target_names = y_labels_vals,       # list of names of the classes
                          title        = best_estimator_name) # title of graph

    Citiation
    ---------
    http://scikit-learn.org/stable/auto_examples/model_selection/plot_confusion_matrix.html

    """
    import matplotlib.pyplot as plt
    import numpy as np
    import itertools

    accuracy = np.trace(cm) / float(np.sum(cm))
    misclass = 1 - accuracy

    if cmap is None:
        cmap = plt.get_cmap('Blues')

    plt.figure(figsize=(8, 6))
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()

    if target_names is not None:
        tick_marks = np.arange(len(target_names))
        plt.xticks(tick_marks, target_names, rotation=45)
        plt.yticks(tick_marks, target_names)

    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]


    thresh = cm.max() / 1.5 if normalize else cm.max() / 2
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        if normalize:
            plt.text(j, i, "{:0.4f}".format(cm[i, j]),
                     horizontalalignment="center",
                     color="white" if cm[i, j] > thresh else "black")
        else:
            plt.text(j, i, "{:,}".format(cm[i, j]),
                     horizontalalignment="center",
                     color="white" if cm[i, j] > thresh else "black")


    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label\naccuracy={:0.4f}; misclass={:0.4f}'.format(accuracy, misclass))
    plt.show()
    
def cb3_calculateResults1(pred_y, actual_y):
    t = np.equal(pred_y, actual_y)
    f = np.not_equal(pred_y, actual_y)
    p = pred_y==1
    n = pred_y==0
    tp = np.sum(np.logical_and(t, p))
    tn = np.sum(np.logical_and(t, n))
    fp = np.sum(np.logical_and(f, p))
    fn = np.sum(np.logical_and(f, n))
    return (tp, tn, fp, fn)
    
def cb3_calculateResults2(tp, tn, fp, fn):
    accuracy = (tp + tn)/(tp + tn + fp + fn)
    precision = None
    if (tp + fp)>0:
        precision = tp / (tp + fp)
    recall = None
    if (tp + fn)>0:
        recall = tp / (tp + fn)
    f1 = (2.0*tp) / (2.0*tp + fp + fn)
    cm = np.array([[tn, fp], [fn, tp]])
    return (accuracy, precision, recall, f1, cm)

def cb3_displayResults(accuracy, precision, recall, f1, cm, description):
    print("\nResults for " + description + ":")
    print("Accuracy: ", accuracy)
    print("Precision: ", precision)
    print("Recall: ", recall)
    print("F1 Score: ", f1)
    cb3_plot_confusion_matrix(cm, normalize=False, target_names=['Good Loans', 'Bad Loans'], title=description)
    
# Define functions to build and compile a model based on hyperparameters
# function to build model based on various hyperparameters
def build_model(feature_count, regularization_factor, hidden_layer_count, units_per_hidden_layer, batch_normalization):
    model = Sequential()
    l2_reg = regularizers.l2(regularization_factor)  # regularization factor
    he_init = initializers.he_normal(seed=None)
    glorot_init = initializers.glorot_normal(seed=None)

    # Add the hidden layers
    for i in range(hidden_layer_count):
        if (i==0):
            model.add(Dense(units_per_hidden_layer, kernel_initializer=he_init, activation='relu', activity_regularizer=l2_reg, input_shape=(feature_count,))) # Kaiming He initialization good for ReLU activation
        else:
            model.add(Dense(units_per_hidden_layer, kernel_initializer=he_init, activation='relu', activity_regularizer=l2_reg)) # Kaiming He initialization good for ReLU activation  
        if (batch_normalization):
            model.add(BatchNormalization())
    # Add an output layer
    model.add(Dense(1, kernel_initializer=glorot_init, activation='sigmoid', activity_regularizer=l2_reg)) # Xavier Glorot initialization good for sigmoid or tanh activation
    return(model)

# function to compile model based on additional hyperparameters
def compile_model(model, lr=0.001, beta_1=0.9, beta_2=0.999, epsilon=1.e-8, decay=0.0, amsgrad=False, loss_function='binary_crossentropy'):
    adam = optimizers.Adam(lr=lr, beta_1=beta_1, beta_2=beta_2, epsilon=epsilon, decay=decay, amsgrad=amsgrad)
    model.compile(optimizer=adam, loss=loss_function, metrics=['accuracy'])
    
# function to fit model
def fit_model(model, X_train, y_train, validation_data, epochs=100, batch_size=128, verbose=0):
    history = model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, verbose=verbose, validation_data=validation_data) # batch_size=1 would be stochastic gradient descent
    return(history)

def build_compile_fit_model(X_train, y_train, validation_data, feature_count, regularization_factor, 
                            hidden_layer_count, units_per_hidden_layer, lr, beta_1, beta_2, epsilon, decay, amsgrad, 
                            loss_function, epochs, batch_size, batch_normalization, verbose):
    model = build_model(feature_count, regularization_factor, hidden_layer_count, units_per_hidden_layer, batch_normalization)
    compile_model(model, lr, beta_1, beta_2, epsilon, decay, amsgrad, loss_function)
    history = fit_model(model, X_train, y_train, validation_data, epochs, batch_size, verbose)
    return (model, history)