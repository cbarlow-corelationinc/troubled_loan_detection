import smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def initialize_email(subject):
    sender_email = "cbarlow3.dev@gmail.com"
    receiver_email = "carl.barlow.iii@gmail.com"
    #password = getpass.getpass(prompt='Type your password and press enter: ', stream=None)
    password = "goPr@h@0914"
    
    message = MIMEMultipart("alternative")
    message["Subject"] = subject
    message["From"] = sender_email
    message["To"] = receiver_email
    
    return (sender_email, receiver_email, password, message)
    
def send_email(sender_email, receiver_email, password, message, text, html):   
    # Turn these into plain/html MIMEText objects
    part1 = MIMEText(text, "plain")
    part2 = MIMEText(html, "html")
    
    # Add HTML/plain-text parts to MIMEMultipart message
    # The email client will try to render the last part first
    message.attach(part1)
    message.attach(part2)
    
    # Create secure connection with server and send email
    context = ssl.create_default_context()
    with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
        server.login(sender_email, password)
        server.sendmail(
            sender_email, receiver_email, message.as_string()
        )

def email_result(i, best_lr, best_rf, best_units_per_hidden_layer, best_f1):
    # Create the plain-text and HTML version of your message
    (sender_email, receiver_email, password, message) = initialize_email("Loan analysis update")
    text = "On iteration " + str(i) + \
            "\nBest learning_rate: " + str(best_lr) + \
            "\nBest regularization_factor: " + str(best_rf) + \
            "\nBest units_per_hidden_layer: " + str(best_units_per_hidden_layer) + \
            "\nBest dev set f1 score: " + str(best_f1)
    html = "<html><body><p>On iteration " + str(i) + "<br>" + \
            "Best learning_rate: " + str(best_lr) + "<br>" + \
            "Best regularization_factor: " + str(best_rf) + "<br>" + \
            "Best units_per_hidden_layer: " + str(best_units_per_hidden_layer) + "<br>" + \
            "Best dev set f1 score: " + str(best_f1) + \
            "</p></body></html"
    send_email(sender_email, receiver_email, password, message, text, html)
        
def email_completion_notice():
    (sender_email, receiver_email, password, message) = initialize_email("Loan analysis completion")
    text = "Loan analysis complete!"
    html = ("<html><body><p>Loan analysis complete!</p></body></html")
    send_email(sender_email, receiver_email, password, message, text, html)
